# -*- coding: utf-8 -*-
from django.utils.translation import ugettext_lazy as _
TEMPLATES = {
    'right_col_two.html': _('Two columns'),
    'right_col_three.html': _('Three columns'),
}
