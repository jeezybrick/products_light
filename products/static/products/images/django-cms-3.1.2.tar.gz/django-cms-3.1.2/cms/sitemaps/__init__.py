# -*- coding: utf-8 -*-
from .cms_sitemap import CMSSitemap  # nopyflakes
